# Contributor Covenant Code of Conduct

## Our Pledge
We pledge to make participation in our project a harassment-free experience for everyone, regardless of age, gender, race, or background.

## Our Standards
Examples of behavior that contributes to a positive environment:
- Using welcoming and inclusive language
- Being respectful of differing viewpoints
- Gracefully accepting constructive criticism

Examples of unacceptable behavior:
- Harassment or discriminatory comments
- Trolling or insulting remarks

## Enforcement
Instances of unacceptable behavior may be reported to the project team at **[your email here]**.  
All complaints will be reviewed and acted upon fairly.

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org/).
