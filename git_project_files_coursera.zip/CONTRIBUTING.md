# Contributing Guidelines

Thank you for considering contributing to this project! 🎉

## How to Contribute
1. **Fork** the repository.
2. Create a new **branch** for your feature or bugfix.
3. **Commit** your changes with clear messages.
4. **Push** the branch to your forked repository.
5. Open a **Pull Request** describing your changes.

## Code Style
- Keep scripts simple and well-documented.
- Follow Bash best practices.
- Test your code before submitting.

## Reporting Issues
If you find a bug, please open an issue in the repository with:
- A clear description
- Steps to reproduce
- Expected vs actual behavior
