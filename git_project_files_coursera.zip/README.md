# Simple Interest Calculator

This repository contains a Bash script (`simple-interest.sh`) that calculates **Simple Interest**.

## 📌 Formula
```
SI = (P × R × T) / 100
```
- P = Principal amount  
- R = Rate of Interest  
- T = Time  

## 🚀 How to Run
```bash
chmod +x simple-interest.sh
./simple-interest.sh
```

## 📜 License
This project is licensed under the [Apache 2.0 License](./LICENSE).
